﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Calculator : MonoBehaviour {

	public Text result;
	public Text clearText;

	//1 + 2
	double firstNumber;
	string currentOperator = "";
	bool isNewNumber = true;

	public void onNumberPressed(string pressed){
		if (isNewNumber) {
			this.result.text = pressed;
			isNewNumber = false;
		} else {
			if (this.result.text.Contains (".")) {
				this.result.text += pressed;
			} else {
				double number;
				int pressedNumber;
				if (double.TryParse (this.result.text, out number) && int.TryParse (pressed, out pressedNumber)) {
					double newNumber = (number * 10) + pressedNumber;
					this.result.text = newNumber.ToString ();
				}
			}
		}


		clearText.text = "C";

	}


	public void onDotPressed(){
		if (isNewNumber) {
			this.result.text = "0.";
		} else {
			if (!this.result.text.Contains (".")) {
				this.result.text += ".";
			}
		}

		clearText.text = "C";
	}


	public void onPercentagePressed(){
		double number;
		if (double.TryParse (this.result.text, out number)) {
			double newNumber = number/100;
			this.result.text = newNumber.ToString ();
		}
	}


	public void onTogglePressed(){
		double number;
		if (double.TryParse (this.result.text, out number)) {
			double newNumber = -1*number;
			this.result.text = newNumber.ToString ();
		}

	}


	public void onOperatorPressed(string pressed){

		double number;
		if (double.TryParse (this.result.text, out number)) {
			firstNumber = number;
			currentOperator = pressed;
			isNewNumber = true;
		}

	}

	public void onEqualsPressed(){

		if (currentOperator == "") {
			return;
		}

		double number;
		if (double.TryParse (this.result.text, out number)) {
			double newNumber = 0;
			switch (currentOperator) {

			case "divide":
				newNumber = firstNumber / number;
				break;

			case "multiply":
				newNumber = firstNumber * number;
				break;

			case "minus":
				newNumber = firstNumber - number;
				break;

			case "plus":
				newNumber = firstNumber + number;
				break;

			}

			this.result.text = newNumber.ToString ();
			isNewNumber = true;
			clearText.text = "AC";

		}

	}

	public void onClearPressed(){
		this.result.text = "0";
		isNewNumber = true;

		if (clearText.text == "AC") {
			firstNumber = 0;
			currentOperator = "";
		} else {
			clearText.text = "AC";
		}
	}



}
